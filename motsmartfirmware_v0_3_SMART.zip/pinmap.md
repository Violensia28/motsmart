
# pinmap.md – #motsmartfirmware v0.3‑SMART r1

Legend & pinout sama seperti rilis sebelumnya. Tidak ada perubahan pin default.
